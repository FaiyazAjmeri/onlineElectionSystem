$(document).ready(function()
{
	$("#validate").click(function()
	{
		var isValid = true;
		
		if($("#firstName").val() == "")
		{
			$("$firstName").next().text("First Name is Required.");
			isValid = false;
		}
		else
		{
			$("$firstName").next().text("");
		}
		
		if($("#lastName").val() == "")
		{
			$("$lastName").next().text("Last Name is Required.");
			isValid = false;
		}
		else
		{
			$("$lastName").next().text("");
		}
		
		if($("#emailId").val() == "")
		{
			$("$emailId").next().text("Email Id is Required.");
			isValid = false;
		}
		else
		{
			$("$emailId").next().text("");
		}
		
		if($("#comment").val() == "")
		{
			$("$comment").next().text("Comment is Required.");
			isValid = false;
		}
		else
		{
			$("$comment").next().text("");
		}
		
		if(isValid)
		{
			$("contactForm").submit();
		}
	});
});


/* Java Script
var $ = function(id) {
	return document.getElementById(id);
}


var validateData = function()
{
	/* Set Variable Valid for Data Valid or Not */
/*	var isValid = true;
	
	/* First Name is Valid or Not */
/*	if($("firstName").value == "")
	{
		$("firstName_error").firstChild.nodeValue = "First Name is Required...";
		isValid = false;
	}
	else
	{
		$("firstName_error").firstChild.nodeValue = "";
	}
	
	/* Last Name is Valid or Not */
/*	if($("lastName").value == "")
	{
		$("lastName_error").firstChild.nodeValue = "Last Name is Required...";
		isValid = false;
	}
	else
	{
		$("lastName_error").firstChild.nodeValue = "";
	}
	
	/* Email Id is Valid or Not */
/*	if($("emailId").value == "")
	{
		$("emailId_error").firstChild.nodeValue = "Email Id is Required...";
		isValid = false;
	}
	else
	{
		$("emailId_error").firstChild.nodeValue = "";
	}
	
	/* Comment is Valid or Not */
/*	if($("comment").value == "")
	{
		$("comment_error").firstChild.nodeValue = "Comment is Required...";
		isValid = false;
	}
	else
	{
		$("comment_error").firstChild.nodeValue = "";
	}
	
	/* Check Data is Valid or Not */
/*	if(isValid)
	{
		$("contactForm").submit();
	}
}

/* Call function when load */
/*window.onload = function()
{
	$("validate").onclick = validateData;
}*/