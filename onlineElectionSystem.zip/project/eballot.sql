-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Aug 11, 2018 at 12:44 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `eballot`
--

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `id` int(11) NOT NULL,
  `firstName` varchar(20) NOT NULL,
  `lastName` varchar(20) NOT NULL,
  `emailId` varchar(50) NOT NULL,
  `comment` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`id`, `firstName`, `lastName`, `emailId`, `comment`) VALUES
(9, 'Nishant', 'Patel', 'nishant.patel@gmail.com', 'Hiiii	\r\n								'),
(10, 'Faiyaz', 'Ajmeri', 'faiyaz.ajmeri@yahoo.in', '	hiiii\r\n								'),
(12, '', '', 'fdfsfsd', '	\r\n			erwwr					'),
(14, '', '', 'aditi.shrma', '	\r\n								'),
(16, '', '', '', '	\r\n								'),
(17, '', '', '', '	\r\n								'),
(19, '', '', '', '	\r\n								'),
(21, 'Faiyaz', 'Ajmeri', 'EWRQWER', ''),
(22, 'Faiyaz', 'Ajmeri', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `id` int(11) NOT NULL,
  `courseName` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `course`
--

INSERT INTO `course` (`id`, `courseName`) VALUES
(1, 'Web design & development'),
(2, 'International Business Management'),
(3, 'Cyber Security'),
(4, 'Cloud Computing'),
(5, 'Business Administration'),
(6, 'Graphic Design');

-- --------------------------------------------------------

--
-- Table structure for table `coursemaster`
--

CREATE TABLE `coursemaster` (
  `courseMasterId` int(11) NOT NULL,
  `courseName` varchar(50) NOT NULL COMMENT 'Course Name',
  `termNumber` varchar(10) NOT NULL COMMENT 'Term Number',
  `groupNumber` varchar(10) NOT NULL COMMENT 'Group Number'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coursemaster`
--

INSERT INTO `coursemaster` (`courseMasterId`, `courseName`, `termNumber`, `groupNumber`) VALUES
(1, 'Web design & development', 'Term 1', 'Group 1'),
(2, 'Web design & development', 'Term 1', 'Group 2'),
(3, 'Web design & development', 'Term 2', 'Group 1'),
(4, 'Web design & development', 'Term 2', 'Group 2'),
(5, 'Web design & development', 'Term 3', 'Group 1'),
(6, 'Web design & development', 'Term 3', 'Group 2'),
(7, 'Web design & development', 'Term 4', 'Group 1'),
(8, 'Web design & development', 'Term 4', 'Group 2');

-- --------------------------------------------------------

--
-- Table structure for table `electiondetails`
--

CREATE TABLE `electiondetails` (
  `electionId` int(11) NOT NULL,
  `voterId` int(11) NOT NULL COMMENT 'registrationVoterId',
  `candidateId` int(11) NOT NULL,
  `electionMasterId` int(11) NOT NULL COMMENT 'electionMasterId',
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `electiondetails`
--

INSERT INTO `electiondetails` (`electionId`, `voterId`, `candidateId`, `electionMasterId`, `status`) VALUES
(20, 10, 1, 8, ''),
(21, 8, 2, 8, ''),
(25, 9, 2, 8, ''),
(27, 7, 2, 8, '');

-- --------------------------------------------------------

--
-- Table structure for table `electionmaster`
--

CREATE TABLE `electionmaster` (
  `electionMasterId` int(11) NOT NULL,
  `courseMasterId` int(11) NOT NULL COMMENT 'ClassMater Id',
  `electionMasterName` varchar(50) NOT NULL,
  `terminateDate` date NOT NULL,
  `status` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `electionmaster`
--

INSERT INTO `electionmaster` (`electionMasterId`, `courseMasterId`, `electionMasterName`, `terminateDate`, `status`) VALUES
(8, 6, 'Web design & development - Term 3 - Group 2', '0000-00-00', 'Running');

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

CREATE TABLE `group` (
  `groupId` int(1) NOT NULL,
  `groupNumber` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `group`
--

INSERT INTO `group` (`groupId`, `groupNumber`) VALUES
(1, 'Group 1'),
(2, 'Group 2'),
(3, 'Group 3'),
(4, 'Group 4');

-- --------------------------------------------------------

--
-- Table structure for table `registrationcandidate`
--

CREATE TABLE `registrationcandidate` (
  `id` int(11) NOT NULL,
  `courseName` varchar(30) NOT NULL,
  `term` varchar(10) NOT NULL,
  `groupId` varchar(10) NOT NULL,
  `studentId` varchar(8) NOT NULL,
  `firstName` varchar(20) NOT NULL,
  `lastName` varchar(20) NOT NULL,
  `emailId` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `mobileNo` varchar(10) NOT NULL,
  `address1` varchar(30) NOT NULL,
  `address2` varchar(30) NOT NULL,
  `city` varchar(20) NOT NULL,
  `country` varchar(10) NOT NULL DEFAULT 'Canada',
  `strength` varchar(500) NOT NULL DEFAULT 'Nothing...',
  `weakness` varchar(500) NOT NULL DEFAULT 'Nothing...',
  `meanByCR` varchar(500) NOT NULL DEFAULT 'Nothing...',
  `doYouDo` varchar(500) NOT NULL DEFAULT 'Nothing...'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registrationcandidate`
--

INSERT INTO `registrationcandidate` (`id`, `courseName`, `term`, `groupId`, `studentId`, `firstName`, `lastName`, `emailId`, `password`, `mobileNo`, `address1`, `address2`, `city`, `country`, `strength`, `weakness`, `meanByCR`, `doYouDo`) VALUES
(1, 'Web design & development', 'Term 3', 'Group 2', 'C0711148', 'Faiyaz', 'Ajmeri', 'faiyaz.ajmeri@yahoo.in', 'faiyaz.ajmeri', '6475448792', '148 - 57 Brickyard way', '', 'Brampton', 'Canada', '																											Communcation Skills\r\n																																', '																		Nothing...																							', 'Class Representative														', '																		Nothing...\r\n																								'),
(2, 'Web design & development', 'Term 3', 'Group 2', 'C0705703', 'Aditi', 'Sharma', 'aditi.sharma@gmail.com', '123', '6475448792', '148 - 57 Brickyard way', '', 'Brampton', 'Canada', 'Nothing...', 'Nothing...', 'Nothing...', 'Nothing...'),
(3, 'Web design & development', 'Term 3', 'Group 2', 'C0710449', 'Kuljeet', 'Kaur', 'kuljeet@gmail.com', '123', '6475448792', '148 - 57 Brickyard way', '', 'Brampton', 'Canada', '									xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx								', '																		Nothing...																', '																		Nothing...																', '																		Nothing...																');

-- --------------------------------------------------------

--
-- Table structure for table `registrationvoter`
--

CREATE TABLE `registrationvoter` (
  `id` int(11) NOT NULL,
  `courseName` varchar(30) NOT NULL,
  `term` varchar(10) NOT NULL,
  `groupId` varchar(10) NOT NULL,
  `studentId` varchar(8) NOT NULL,
  `firstName` varchar(20) NOT NULL,
  `lastName` varchar(20) NOT NULL,
  `emailId` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  `mobileNo` int(10) NOT NULL,
  `address1` varchar(30) NOT NULL,
  `address2` varchar(30) NOT NULL,
  `city` varchar(20) NOT NULL,
  `country` varchar(10) NOT NULL DEFAULT 'Canada'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registrationvoter`
--

INSERT INTO `registrationvoter` (`id`, `courseName`, `term`, `groupId`, `studentId`, `firstName`, `lastName`, `emailId`, `password`, `mobileNo`, `address1`, `address2`, `city`, `country`) VALUES
(7, 'Web design & development', 'Term 3', 'Group 2', 'C0711148', 'FaiyazAjmeri', 'Ajmeri', 'faiyazajmeri@yahoo.in', 'faiyaz.ajmeri', 2147483647, '148 - 57 Brickyard way', '', 'Brampton', 'Canada'),
(8, 'Cyber Security', 'Term 3', 'Group 1', 'C0705701', 'Rutvik', 'Gajjar', 'rutvik.gajjar@gmail.com', '12345678', 2147483647, '148 - 57 Brickyard way', '', 'Brampton', 'Canada'),
(9, 'Web design & development', 'Term 3', 'Group 3', 'C0705703', 'Aditi', 'Sharma', 'aditi.sharma@gmail.com', '12345678', 2147483647, '148 - 57 Brickyard way', '', 'Brampton', 'Canada'),
(10, 'Web design & development', 'Term 2', 'Group 2', 'C0710442', 'Gagandeep', 'Kaur', 'gagandeep@gmail.com', '123', 2147483647, '148 - 57 Brickyard way', '', 'Brampton', 'Canada');

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

CREATE TABLE `result` (
  `resultId` int(11) NOT NULL,
  `electionMasterId` int(11) NOT NULL,
  `candidateId` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `term` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `term`
--

CREATE TABLE `term` (
  `termId` int(1) NOT NULL,
  `termNumber` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `term`
--

INSERT INTO `term` (`termId`, `termNumber`) VALUES
(1, 'Term 1'),
(2, 'Term 2'),
(3, 'Term 3'),
(4, 'Term 4');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `coursemaster`
--
ALTER TABLE `coursemaster`
  ADD PRIMARY KEY (`courseMasterId`);

--
-- Indexes for table `electiondetails`
--
ALTER TABLE `electiondetails`
  ADD PRIMARY KEY (`electionId`),
  ADD UNIQUE KEY `voterId` (`voterId`);

--
-- Indexes for table `electionmaster`
--
ALTER TABLE `electionmaster`
  ADD PRIMARY KEY (`electionMasterId`),
  ADD UNIQUE KEY `courseMasterId` (`courseMasterId`);

--
-- Indexes for table `group`
--
ALTER TABLE `group`
  ADD PRIMARY KEY (`groupId`);

--
-- Indexes for table `registrationcandidate`
--
ALTER TABLE `registrationcandidate`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `emailId` (`emailId`),
  ADD UNIQUE KEY `studentId` (`studentId`);

--
-- Indexes for table `registrationvoter`
--
ALTER TABLE `registrationvoter`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `emailIs` (`emailId`);

--
-- Indexes for table `result`
--
ALTER TABLE `result`
  ADD PRIMARY KEY (`resultId`);

--
-- Indexes for table `term`
--
ALTER TABLE `term`
  ADD PRIMARY KEY (`termId`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
--
-- AUTO_INCREMENT for table `course`
--
ALTER TABLE `course`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `coursemaster`
--
ALTER TABLE `coursemaster`
  MODIFY `courseMasterId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `electiondetails`
--
ALTER TABLE `electiondetails`
  MODIFY `electionId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;
--
-- AUTO_INCREMENT for table `electionmaster`
--
ALTER TABLE `electionmaster`
  MODIFY `electionMasterId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;
--
-- AUTO_INCREMENT for table `group`
--
ALTER TABLE `group`
  MODIFY `groupId` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `registrationcandidate`
--
ALTER TABLE `registrationcandidate`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `registrationvoter`
--
ALTER TABLE `registrationvoter`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
--
-- AUTO_INCREMENT for table `result`
--
ALTER TABLE `result`
  MODIFY `resultId` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `term`
--
ALTER TABLE `term`
  MODIFY `termId` int(1) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
