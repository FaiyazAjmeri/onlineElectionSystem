<?php include 'connect.php' ?>
<?php


$sql = "DELETE FROM contact WHERE id=".$_GET['id']."";

if ($conn->query($sql) === TRUE) {
    echo "New record deleted successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

header('Location: comment.php');    

?>