<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Index Page</title>
		
		<!-- Style Sheets -->
		<link rel="stylesheet" href="../css/admin1.css">
		
		<!-- Java Scripts -->
		<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
	</head>

	<body>

		<main>
			<?php include 'logo.php' ?>
			<?php include 'menu.php' ?>
			<?php include 'footer.php' ?>
		</main>

	</body>	
</html>