<?php include 'connect.php' ?>

<?php 
$sql = "SELECT * FROM contact";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	echo "<table>
				<tr class='heading'>
					<td colspan='7'><h1 align='center'>Feedback</h1></td>
				</tr>
	
				<tr class='title'>
					<th>Index</th>
					<th>First Name</th>
					<th>Last Name</th>
					<th>Email Id</th>
					<th>Comment</th>
					<th>View</th>
					<th>Delete</th>
				</tr>";
				$i = 1;
    while($row = $result->fetch_assoc()) {
		$id = $row["id"];
			echo "<tr>
					<td>".$i."</td>
					<td>".$row["firstName"]."</td>
					<td>".$row["lastName"]."</td>
					<td>".$row["emailId"]."</td>
					<td>".$row["comment"]."</td>
					<td><a href='commentContentView.php?id=$id'>view</a></td>
					<td><a href='commentContentDelete.php?id=$id'>delete</a></td>
				</tr>";
				
				$i++;
   }
   echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
?>



<!--'page2.php?message='.$message1.'&message2='.$message2-->