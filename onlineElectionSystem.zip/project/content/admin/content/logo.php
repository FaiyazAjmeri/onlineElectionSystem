<header>
				<div id="w">
					<img src="../image/logo.png" width="250px" height="50px">
				</div>
</header>