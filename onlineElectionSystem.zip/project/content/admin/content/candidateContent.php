<?php include 'connect.php' ?>

<?php 
$sql = "SELECT * FROM registrationcandidate";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // output data of each row
	echo "<table>
				<tr class='heading'>
					<td colspan='7'><h1 align='center'>Candidate's Detail</h1></td>
				</tr>
	
				<tr class='title'>
					<th>Index</th>
					<th>Course Name</th>
					<th>Term</th>
					<th>Student Id</th>
					<th>First Name</th>
					<th>View</th>
					<th>Delete</th>
				</tr>";
				
				$i = 1;
    while($row = $result->fetch_assoc()) {
		$id = $row["id"];
			echo "<tr>
					<td>".$i."</td>
					<td>".$row["courseName"]."</td>
					<td>".$row["term"]."</td>
					<td>".$row["studentId"]."</td>
					<td>".$row["firstName"]."</td>
					<td><a href='candidateContentView.php?id=$id'>view</a></td>
					<td><a href='candidateContentDelete.php?id=$id'>delete</a></td>
				</tr>";
				
				$i++;
   }
   echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
?>



<!--'page2.php?message='.$message1.'&message2='.$message2-->