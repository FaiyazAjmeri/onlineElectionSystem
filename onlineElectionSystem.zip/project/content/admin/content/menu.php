		<nav>
			<div id="header">
				<ul class="menu fontstyle">
					<li><a href="index.php">Home</a></li>
					<li>Data
						<ul class="submenu">
							<li><a href="voter.php">Voter</a></li>
							<li><a href="candidate.php">Candidate</a></li>
							<li><a href="comment.php">Comment</a></li>
						</ul>
					</li>
					<li>Report
						<ul class="submenu">
							<li><a href="user.php">Users</a></li>
						</ul>
					</li>
					<li>About Us</li>
					<li><a href="contactUs.php">Contact Us</a></li>
				</ul>
			</div>
		<nav>