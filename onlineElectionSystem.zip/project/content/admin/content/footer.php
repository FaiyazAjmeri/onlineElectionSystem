			<!-- Footer Section -->
			
			<footer>
				<div id="w">
					<div id="footerblk">
						<div class="links">
							<div class="heading">Online Election System</div><br>
							<ul>
								<li><a href="index.php">Home</a>&nbsp; &nbsp; &gt;</li>
								<li><a href="">Voting</a>&nbsp; &nbsp; &gt;</li>
								<li><a href="">About Us</a>&nbsp; &nbsp; &gt;</li>
								<li><a href="">Contact Us</a></li>
							</ul>
						</div>
						
						<div class="follows">
							<div class="heading">Follow Us</div>
							<ul>
								<li><a href="https://www.facebook.com/newGenerationVoting/">Facebook</a></li>
								<li><a href="">Instagram</a></li>
								<li><a href="">Twitter</a></li>
								<li><a href="">Youtube</a></li>
							</ul>
						</div>
					</div>
				</div>
			</footer>