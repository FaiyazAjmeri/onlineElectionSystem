<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Comment</title>
		
		<!-- Style Sheets -->
		<link rel="stylesheet" href="../css/admin1.css">
		
		<style type="text/css">
			table
			{
				font-family: "Lucida Grande", "Lucida Sans Unicode", "Lucida Sans", "DejaVu Sans", "sans-serif";
				color: #d91a29;
				margin-left: -8px;
				margin-top : 20px;
				margin-bottom: 20px;
				width: 100%;
				border: 1px dotted #d91a29;
			}
			
			table .heading
			{
				background: #d91a29;
				color: #fff;
				font-size: 200%;
				padding: 10px;
				height: 50px;
				text-align: center;
			}
			
			table .title
			{
				background: #d91a29;
				color: #fff;
				padding: 10px;
				height: 50px;
				text-align: center;
			}
			
			table tr:hover
			{
				background: #333;
				color: #fff;
			}
			
			table td
			{
				padding: 10px;
				text-align: center;
			}
		</style>
		
		<!-- Java Scripts -->
		<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
	</head>

	<body>

		<main>
			<?php include 'logo.php' ?>
			<?php include 'menu.php' ?>
			<?php include 'commentContent.php' ?>
			<?php include 'footer.php' ?>
		</main>

	</body>	
</html>