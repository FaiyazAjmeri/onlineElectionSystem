<?php
	include 'connect.php';
	
	
	$candidateId = $_POST['cid'];
	$cfirstName = $_POST['cfirstName'];
	$clastName = $_POST['clastName'];
	
	$voterId = $_POST['voterId'];
	$vcourseName = $_POST['vcourseName'];
	$vterm = $_POST['vterm'];
	$vgroupId = $_POST['vgroupId'];
	$vstudentId = $_POST['vstudentId'];
	$vfirstName = $_POST['vfirstName'];
	$vlastName = $_POST['vlastName'];
	$vemailId = $_POST['vemailId'];
	$vmobile = $_POST['vmobile'];
	$vaddress1 = $_POST['vaddress1'];
	$vaddress2 = $_POST['vaddress2'];
	$vcity = $_POST['vcity'];
	
	//echo $voterId."<br>".$vcourseName."<br>".$vterm."<br>".$vgroupId."<br>";
	
	$sql = "SELECT * FROM coursemaster where courseName='".$vcourseName."' AND termNumber='".$vterm."' AND groupNumber='".$vgroupId."'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) 
	{
		while($row = $result->fetch_assoc()) 
		{
			$vcourseId = $row["courseMasterId"];
			$electionMasterName = $vcourseName." - ".$vterm." - ".$vgroupId;
			
			//echo $vcourseId;
			
			
			//Insert Record into Election Master...
			
			$sql = "INSERT INTO electionmaster(courseMasterId, electionMasterName, status)
					VALUES ('$vcourseId', '$electionMasterName', 'Running')";

			if ($conn->query($sql) === TRUE) 
			{
				echo "New record created successfully";
			} 
			
			//Get Election Master Id from Election Master Table
			
			$sql = "SELECT * FROM electionmaster where courseMasterId='".$vcourseId."'";
			$result = $conn->query($sql);
			
			if ($result->num_rows > 0) 
			{
				while($row = $result->fetch_assoc()) 
				{
					$electionMasterId = $row["electionMasterId"];
					
					//Insert Record into Election Master...
			
					$sql = "INSERT INTO electiondetails(voterId, candidateId, electionMasterId)
					VALUES ('$voterId', '$candidateId', '$electionMasterId')";

					if ($conn->query($sql) === TRUE) 
					{
						//echo "New record created successfully";
						header("location: voterIndexVoteSubmission.php?vemailId=$vemailId&cfirstName=$cfirstName&clastName=$clastName");
					} 
					else 
					{
						//echo "Error: " . $sql . "<br>" . $conn->error;
						header("location: voterIndexVoteSubmissionError.php?vemailId=$vemailId&voterId=$voterId");
					}
				}
			}
			else
			{
				echo "0 results";
			}
		}
	}
	else
	{
		echo "0 results";
	}
?>