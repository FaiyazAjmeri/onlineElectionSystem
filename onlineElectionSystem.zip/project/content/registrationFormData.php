<?php include 'connect.php' ?>
<?php

$courseName = $_POST['courseName'];
$term = $_POST['term'];
$group = $_POST['group'];
$studentId = $_POST['studentId'];

$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$emailId = $_POST['emailId'];
$password = $_POST['password'];
$mobile = $_POST['mobile'];
$address1 = $_POST['addLine1'];
$address2 = $_POST['addLine2'];
$city = $_POST['city'];

$sql = "INSERT INTO registrationvoter (courseName, term, groupId, studentId, firstName, lastName, emailId, password, mobileNo, address1, address2, city)
VALUES ('$courseName', '$term', '$group', '$studentId', '$firstName', '$lastName', '$emailId', '$password', '$mobile', '$address1', '$address2', '$city')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

//header('Location: index.php');    

?>