<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Index Page</title>
		
		<!-- Style Sheets -->
		<link rel="stylesheet" href="../css/main1.css">
		
		<!-- Java Scripts -->
		<script src="https://maps.googleapis.com/maps/api/js?sensor=false"></script>
		<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
		
		<script>
		$(document).ready(function(){
			var map;
			var geocoder = new google.maps.Geocoder();
			geocoder.geocode({address: "121 Brunnel Road, Mississauga, Ontario, Canada"}, function(results) {
				var homeLatLng = results[0].geometry.location;
				var mapOptions = {
					zoom: 7, 
					center: homeLatLng, 
					mapTypeId: google.maps.MapTypeId.ROADMAP
				};
				map = new google.maps.Map($("#map").get(0), mapOptions);
				
				// add the marker for that location on the map
				var marker = new google.maps.Marker({
								position: homeLatLng,  //Address of College
								map: map
							});
				
			});
		});
		</script>
	</head>

	<body>

		<main>
			<?php include 'logo.php' ?>
			<?php include 'menu.php' ?>
			<?php include 'slideshow.php' ?>
			<?php include 'events.php' ?>
			<?php include 'maps.php' ?>
			<?php include 'footer.php' ?>
		</main>

	</body>	
	
		<!-- Script for Slideshow -->
		
		<script>
			var slideIndex = 0;
			showSlides();

			function showSlides() {
				var i;
				var slides = document.getElementsByClassName("mySlides");
				var dots = document.getElementsByClassName("dot");
				for (i = 0; i < slides.length; i++) {
					slides[i].style.display = "none";  
				}
				slideIndex++;
				if (slideIndex > slides.length) {slideIndex = 1}    
				for (i = 0; i < dots.length; i++) {
					dots[i].className = dots[i].className.replace(" active", "");
				}
				slides[slideIndex-1].style.display = "block";  
				dots[slideIndex-1].className += " active";
				setTimeout(showSlides, 3000); // Change image every 2 seconds
			}
		</script>
</html>