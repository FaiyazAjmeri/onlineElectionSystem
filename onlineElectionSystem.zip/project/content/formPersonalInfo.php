<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Course Information</title>
		
		<style type="text/css">
			body
			{
				width:99%;
				background-color:#333;
			}
			
			main
			{
				margin-left:10%;
				margin-right:10%;
			}
			
			#w
			{
				width:100%;
			}
			
			
			
			/* Form Section */
			.form-content
			{
				/*margin-top:10px;
				margin-bottom:10px;*/
				margin: 110px 200px;
				box-shadow: 0 0 6px black;
				border-radius: 10px;
				padding: 20px 12px 10px 20px;
				font: 13px Arial, Helvetica, sans-serif;
				border: 1px solid;
			}
	
			.form-heading
			{
				font-weight: bold;
				
				margin-bottom: 20px;
				font-size: 18px;
				
				
				border-bottom: 1px solid #333;
				border-top: 1px solid #333;
				color: #fff;
				border-radius: 10px 10px 0px 0px;
				margin-top:-21px;
				margin-left:-20px;
				text-transform: uppercase;
				background: #d91a29;
				width:101.8%;
				padding: 10px;
			}

			.form-content label
			{
				display: block;
				margin: 0px 0px 15px 0px;
				color: #fff;
			}

			.form-content label > span
			{
				width: 100px;
				font-weight: bold;
				float: left;
				padding-top: 8px;
				padding-right: 5px;
			}
	
			.form-content span.required
			{
				color:red;
			}
		
			.form-content input.input-field
			{
				margin-right:5px;
			}
	
			.form-content input.input-field,
			.form-content .textarea-field, 
			.form-content .select-field
			{
				border: 1px solid #C2C2C2;
				box-shadow: 1px 1px 4px #EBEBEB;
				border-radius: 5px;
				padding: 5px;
			}

			.form-content input[type=submit],
			.form-content input[type=reset]
			{
				margin-top: 5px;
				padding: 10px;
				width: 100px;
				color: #ffffff;
				background: #d91a29;
				text-align: center;
				border-radius: 5px;
			}

			.form-content input[type=submit]:hover,
			.form-content input[type=reset]:hover
			{
				background: #333;
			}
			
		</style>
		
	</head>

	<body>
		<main>
			
			<!-- Form Section -->
			
			<section>
				<div class="form-content">
					<div class="form-heading">Personal Information</div>
						<form action="formAccountType.php" name="formPersonalInformation" method="post" autocomplete="off">
						
							<?php
							
								$courseName = $_POST['courseName'];
								$term = $_POST['term'];
								$groupId = $_POST['groupId'];
								$studentId = $_POST['studentId'];
								
								//echo $courseName;
							?>
							
							<input type="hidden" name="courseName" id="courseName" value="<?php echo $courseName; ?>">
							<input type="hidden" name="term" id="term" value="<?php echo $term; ?>">
							<input type="hidden" name="groupId" id="groupId" value="<?php echo $groupId; ?>">
							<input type="hidden" name="studentId" id="studentId" value="<?php echo $studentId; ?>">
					
							<label for="firstName">
								<span>Name <span class="required">*</span></span>
								<input type="text" class="input-field" name="firstName" id="firstName" value="" placeholder="First Name" required pattern="[A-Za-z]+" title="Only Characters are allowed." />
								<input type="text" class="input-field" name="lastName" id="lastName" value="" placeholder="Last Name" required pattern="[A-Za-z]+" title="Only Characters are allowed." />
							</label>
							
							<label for="email"><span>Email <span class="required">*</span></span>
								<input type="email" class="input-field" name="emailId" id="emailId" value="" placeholder="Email Address" required />
							</label>
							
							<label for="password"><span>Password <span class="required">*</span></span>
								<input type="password" class="input-field" name="password" id="password" value="" placeholder="Password" required pattern="[A-Za-z0-9-.@]+" />
							</label>
							
							<label for="mobile"><span>Mobile No.<span class="required">*</span></span>
								<input type="text" class="input-field" name="mobile" id="mobile" value="" placeholder="Mobile Number" required maxlength="10" minlength="10" pattern="[0-9]+" title="Only 10 digits are allowed." />
							</label>
							
							<label for="addLine1"><span>Address<span class="required">*</span></span>
								<input type="text" class="input-field" name="addLine1" id="addLine1" value="" placeholder="Address Line1" required />
								<input type="text" class="input-field" name="addLine2" id="addLine2" value="" placeholder="Address Line2" />
							</label>
							
							<label for="city"><span>City<span class="required">*</span></span>
								<select name="city" id="city" class="select-field">
									<option>Brampton</option>
									<option>Mississuaga</option>
									<option>Etobicoke</option>
									<option>Orangeville</option>
								</select>
							</label>
							
							<label for="country"><span>Country</span>
								<input type="text" class="input-field" name="country" id="country" value="Canada" readonly />
							</label>
							
							<label><span>&nbsp;</span>
								<input type="submit" value="Submit" />
								<input type="reset" value="Clear" />
							</label>
							
						</form>
				</div>
			</section>
		</main>
	</body>
</html>