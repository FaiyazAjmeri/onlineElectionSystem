<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Results</title>
		
		<!-- Style Sheets -->
		<link rel="stylesheet" href="../css/main1.css">
		
		<!-- Java Scripts -->
		<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
		<script src="../js/contactUsValidate.js"></script>
		
		
		<style type="text/css">
			/* Form Section */
			.form-content
			{
				margin-top:10px;
				margin-bottom:10px;
				margin-right: 12px;
				box-shadow: 0 0 6px #666666;
				border-radius: 10px;
				padding: 20px 12px 10px 20px;
				font: 13px Arial, Helvetica, sans-serif;
				border: 1px solid;
			}
	
			.form-heading
			{
				font-weight: bold;
				
				margin-bottom: 20px;
				font-size: 18px;
				
				
				border-bottom: 1px solid #333;
				border-top: 1px solid #333;
				color: #fff;
				border-radius: 10px 10px 0px 0px;
				margin-top:-21px;
				margin-left:-20px;
				text-transform: uppercase;
				background: #d91a29;
				width:101.1%;
				padding: 10px;
			}

			.form-content label
			{
				display: block;
				margin: 0px 0px 15px 0px;
			}

			.form-content label > span
			{
				width: 220px;
				font-weight: bold;
				float: left;
				padding-top: 8px;
				padding-right: 5px;
			}
	
			.form-content span.required
			{
				color:red;
			}
		
			.form-content input.input-field
			{
				margin-right:5px;
			}
	
			.form-content input.input-field, 
			.form-content .textarea-field, 
			.form-content .select-field
			{
				border: 1px solid #C2C2C2;
				box-shadow: 1px 1px 4px #EBEBEB;
				border-radius: 5px;
				padding: 5px;
			}

			.form-content .textarea-field
			{
				height:60px;
				width: 300px;
			}

			.form-content input[type=submit],
			.form-content input[type=reset]
			{
				margin-top: 5px;
				padding: 10px;
				width: 100px;
				color: #ffffff;
				background: #d91a29;
				text-align: center;
				border-radius: 5px;
			}

			.form-content input[type=submit]:hover,
			.form-content input[type=reset]:hover
			{
				background: #333;
			}
			
			.table
			{
				font-family: "Lucida Grande", "Lucida Sans Unicode", "Lucida Sans", "DejaVu Sans", "sans-serif";
				color: #d91a29;
				//margin-left: 9%;
				margin-top : 20px;
				margin-bottom: 20px;
				width: 100%;
				border: 1px dotted #d91a29;
			}
			
			.table .heading
			{
				background: #d91a29;
				color: #fff;
				font-size: 120%;
				padding: 10px;
				height: 50px;
			}
			
			.table tr:hover
			{
				background: #333;
				color: #fff;
			}
			
			.table td
			{
				padding: 10px;
				text-align:center;
			}

		</style>
	</head>

	<body>

		<main>
			<?php include 'logo.php' ?>
			<?php include 'menu.php' ?>
			
			<!-- Form Section -->
			
			<section>
				<div class="form-content">
					<div class="form-heading">Result Information</div>
						<form action="result.php" name="contactForm" id="contactForm" method="post">
							
							<label for="courseName">
								<span>Choose Course - Term - Group :<span class="required">*</span></span>
								<select name="electionMasterId" id="electionMasterId" class="select-field">
									<?php 
										include 'connect.php';
										
										$sql = "SELECT * FROM electionmaster";
										$result = $conn->query($sql);
					
										if($result->num_rows > 0) 
										{
											while($row = $result->fetch_assoc()) 
											{
												$electionMasterId = $row['electionMasterId'];
												$electionMasterName = $row['electionMasterName'];
									?>
										<option value="<?php echo $electionMasterId; ?>"><?php echo $electionMasterName; ?></option>
									<?php
											}
										} 
										else 
										{
											echo "0 results";
										}
										$conn->close();
									?>
								</select>
							</label>
							
							<label><span>&nbsp;</span>
								<input type="submit" value="Submit" id="validate" name="validate" />
								<input type="reset" value="Clear" />
							</label>
						</form>
				</div>
			</section>
			
			<!-- Result Table Section -->
			<?php
				if(isset($_POST['electionMasterId']))
				{
			?>
			
			<section>
				<table class='table'>
						
					<tr class='heading'>
						<th width='25%'>Candidate Name</th>
						<th width='30%'>Course Name</th>
						<th>Term</th>
						<th>Group</th>
						<th>Count</th>
					</tr>
					
					<?php 
						include 'connect.php';
						
						$electionMasterId = $_POST['electionMasterId'];
						
						$sql = "SELECT COUNT(e.voterId) as votes, e.candidateId as candidateId, c.id, c.firstName as firstName, c.lastName, c.courseName, c.term, c.groupId
								FROM electiondetails e, registrationcandidate c 
								WHERE e.candidateId = c.id AND e.candidateId = c.id Group By e.candidateId";
						$result = $conn->query($sql);
					
						if($result->num_rows > 0) 
						{
							while($row = $result->fetch_assoc()) 
							{
								$votes = $row['votes'];
								$candidateId = $row['candidateId'];
								$firstname = $row['firstName'];
								$lastname = $row['lastName'];
								$courseName = $row['courseName'];
								$term = $row['term'];
								$groupId = $row['groupId'];
								
								$candidateName = $firstname." ".$lastname;
					?>					
						<tr>
							<td><?php echo $candidateName; ?></td>
							<td><?php echo $courseName; ?></td>
							<td><?php echo $term; ?></td>
							<td><?php echo $groupId; ?></td>
							<td><?php echo $votes; ?></td>
						</tr>
					<?php		
							}
						} 
						else 
						{
							echo "0 results";
						}
						$conn->close();
					?>
					
				</table>
			
			</section>
			
			<?php
				}
			?>
			
			
			<!--  Extra Result Table Section 
			
			<section>
				<table class='table'>
						
					<tr class='heading'>
						<th width='30%'>Candidate Name</th>
						<th>Count</th>
					</tr>
				
					<?php /*
						include 'connect.php';
						
						$electionMasterId = $_POST['electionMasterId'];
						
						$sql = "SELECT COUNT(distinct voterId) as votes, candidateId FROM electiondetails  Group By candidateId";
						$result = $conn->query($sql);
					
						if($result->num_rows > 0) 
						{
							while($row = $result->fetch_assoc()) 
							{
								$candidateId = $row['candidateId'];
								$votes = $row['votes'];
					?>					
						<tr>
							<td><?php echo $candidateId; ?></td>
							<td><?php echo $votes; ?></td>
						</tr>
					<?php		
							}
						} 
						else 
						{
							echo "0 results";
						}
						$conn->close();
					*/?>
					
				</table>
			
			</section>
			-->
			
			
			<?php include 'footer.php' ?>
		</main>
		
	</body>	
</html>
