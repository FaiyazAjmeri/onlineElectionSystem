<?php 
	include 'connect.php';

	$courseName = $_POST['courseName'];
	$term = $_POST['term'];
	$groupId = $_POST['groupId'];
	$studentId = $_POST['studentId'];
						
	$firstName = $_POST['firstName'];
	$lastName = $_POST['lastName'];
	$emailId = $_POST['emailId'];
	$password = $_POST['password'];
	$mobile = $_POST['mobile'];
	$address1 = $_POST['address1'];
	$address2 = $_POST['address2'];
	$city = $_POST['city'];
	
	$type = $_POST['type'];
	
	if($type == "voter")
	{
		$sql = "INSERT INTO registrationvoter (courseName, term, groupId, studentId, firstName, lastName, emailId, password, mobileNo, address1, address2, city)
		VALUES ('$courseName', '$term', '$groupId', '$studentId', '$firstName', '$lastName', '$emailId', '$password', '$mobile', '$address1', '$address2', '$city')";

		if ($conn->query($sql) === TRUE) {
				//echo "New record created successfully";
				echo "<script>alert('Your Voter account created successfully');document.location='voterIndex.php?emailId=$emailId'</script>";
				
		} else {
			echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();

		//header("Location: voterIndex.php?emailId=$emailId");

	}
	else
	{
		//echo "Under Construction";
		
		$sql = "INSERT INTO registrationcandidate (courseName, term, groupId, studentId, firstName, lastName, emailId, password, mobileNo, address1, address2, city)
		VALUES ('$courseName', '$term', '$groupId', '$studentId', '$firstName', '$lastName', '$emailId', '$password', '$mobile', '$address1', '$address2', '$city')";

		if ($conn->query($sql) === TRUE) {
				//echo "New record created successfully";
				echo "<script>alert('Your Candidate account created successfully');document.location='candidateIndex.php?emailId=$emailId'</script>";
		} else {
			echo "Error: " . $sql . "<br>" . $conn->error;
		}

		$conn->close();

		//header("Location: candidateIndex.php?emailId=$emailId");   
	}
?>