			<section>
				<div class="form-content">
					<div class="form-heading">Course Information</div>
						<form action="registrationFormData.php" name="registrationForm" id="registrationForm" method="post">
							<div class="course">
							<label for="courseName">
								<span>Course Name <span class="required">*</span></span>
									<select name="courseName" id="courseName" class="select-field">
									<option>Select Course</option>
									<option value="Web design & development">Web design & development</option>
									<option value="International Business Management">International Business Management</option>
									<option value="Cyber Security">Cyber Security</option>
									<option value="Cloud Computing">Cloud Computing</option>
									<option value="Business Administration">Business Administration</option>
									<option value="Graphic Design">Graphic Design</option>
								</select>
							</label>
							
							<label for="term">
								<span>Term <span class="required">*</span></span>
									<select name="term" id="term" class="select-field">
									<option>Select Term</option>
									<option value="Term 1">Term 1</option>
									<option value="Term 2">Term 2</option>
									<option value="Term 3">Term 3</option>
									<option value="Term 4">Term 4</option>
								</select>	
							</label>
							
							<label for="grouo">
								<span>Group <span class="required">*</span></span>
									<select name="group" id="group" class="select-field">
									<option>Select Group</option>
									<option value="Group 1">Group 1</option>
									<option value="Group 2">Group 2</option>
									<option value="Group 3">Group 3</option>
									<option value="Group 4">Group 4</option>
								</select>	
							</label>
							
							<label for="studentId">
							<span>Student Id <span class="required">*</span></span>
								<input type="text" class="input-field" name="studentId" id="studentId" value="" placeholder="Student Id" required pattern="[A-Za-z0-9]*" />
							</label>
							</div>	
							<div class="form-heading2">Personal Information</div>
							
							<label for="firstName">
								<span>Name <span class="required">*</span></span>
								<input type="text" class="input-field" name="firstName" id="firstName" value="" placeholder="First Name" required pattern="[A-Za-z]*" />
								<input type="text" class="input-field" name="lastName" id="lastName" value="" placeholder="Last Name" required />
							</label>
							
							<label for="email"><span>Email <span class="required">*</span></span>
								<input type="email" class="input-field" name="emailId" id="emailId" value="" placeholder="Email Address" />
							</label>
							<label for="password"><span>Password <span class="required">*</span></span>
								<input type="password" class="input-field" name="password" id="password" value="" placeholder="Password" />
							</label>
							<label for="mobile"><span>Mobile No.<span class="required">*</span></span>
								<input type="text" class="input-field" name="mobile" id="mobile" value="" placeholder="Mobile Number" required />
							</label>
							<label for="addLine1"><span>Address</span>
								<input type="text" class="input-field" name="addLine1" id="addLine1" value="" placeholder="Address Line1" />
								<input type="text" class="input-field" name="addLine2" id="addLine2" value="" placeholder="Address Line2" />
							</label>
							<label for="city"><span>City<span class="required">*</span></span>
								<select name="city" id="city" class="select-field">
									<option>Select City</option>
									<option>Brampton</option>
									<option>Mississuaga</option>
									<option>Etobicoke</option>
									<option>Orangeville</option>
								</select>
							</label>
							<label for="country"><span>Country</span>
								<input type="text" class="input-field" name="country" id="country" value="Canada" readonly />
							</label>
							
							<!--
							<label for="comments"><span>Comments</span>
								<textarea class="textarea-field">
	
								</textarea>
							</label>
							-->
							<label><span>&nbsp;</span>
								<input type="submit" value="Submit" />
								<input type="reset" value="Clear" />
							</label>
						</form>
				</div>

			</section>