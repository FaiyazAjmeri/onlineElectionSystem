<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Login</title>
		
		<style type="text/css">
			body
			{
				width:99%;
				background-color:#333;
			}
			
			main
			{
				margin-left:10%;
				margin-right:10%;
			}
			
			#w
			{
				width:100%;
			}
			
			
			
			/* Form Section */
			.form-content
			{
				/*margin-top:10px;
				margin-bottom:10px;*/
				margin: 240px 200px;
				box-shadow: 0 0 6px black;
				border-radius: 10px;
				padding: 20px 12px 10px 20px;
				font: 13px Arial, Helvetica, sans-serif;
				border: 1px solid;
			}
	
			.form-heading
			{
				font-weight: bold;
				
				margin-bottom: 20px;
				font-size: 18px;
				
				
				border-bottom: 1px solid #333;
				border-top: 1px solid #333;
				color: #fff;
				border-radius: 10px 10px 0px 0px;
				margin-top:-21px;
				margin-left:-20px;
				text-transform: uppercase;
				background: #d91a29;
				width:101.8%;
				padding: 10px;
			}

			.form-content label
			{
				display: block;
				margin: 0px 0px 15px 0px;
				color: #fff;
			}

			.form-content label > span
			{
				width: 100px;
				font-weight: bold;
				float: left;
				padding-top: 8px;
				padding-right: 5px;
			}
	
			.form-content span.required
			{
				color:red;
			}
		
			.form-content input.input-field
			{
				margin-right:5px;
			}
	
			.form-content input.input-field
			{
				border: 1px solid #C2C2C2;
				box-shadow: 1px 1px 4px #EBEBEB;
				border-radius: 5px;
				padding: 5px;
			}

			.form-content input[type=submit],
			.form-content input[type=reset]
			{
				margin-top: 5px;
				padding: 10px;
				width: 100px;
				color: #ffffff;
				background: #d91a29;
				text-align: center;
				border-radius: 5px;
			}

			.form-content input[type=submit]:hover,
			.form-content input[type=reset]:hover
			{
				background: #333;
			}
			
			p
			{
				color: #fff;
				font: 13px Arial, Helvetica, sans-serif;
				font-weight: bold;
				font-size: 100%;
			}
		</style>
		
	</head>

	<body>
		<main>
			
			<!-- Form Section -->
			
			<section>
				<div class="form-content">
					<div class="form-heading">Done...</div>
							<?php $vemailId = $_GET['vemailId'];?>
						<form action="voterIndex.php?emailId=<?php echo $vemailId;?>" name="myform" method="post" autocomplete="off">
							<?php 
									$candidateName = $_GET['cfirstName']." ".$_GET['clastName'];
									
									echo '<p>You Submitted your Vote to the : '.$candidateName.'</p>';
							?>
						
							<label><span>&nbsp;</span>
								<input type="submit" value="Submit" />
							</label>
						</form>
				</div>
			</section>
		</main>
	</body>
</html>