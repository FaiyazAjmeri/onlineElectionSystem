<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Course Information</title>
		
		<style type="text/css">
			body
			{
				width:99%;
				background-color:#333;
			}
			
			main
			{
				margin-left:10%;
				margin-right:10%;
			}
			
			#w
			{
				width:100%;
			}
			
			
			
			/* Form Section */
			.form-content
			{
				/*margin-top:10px;
				margin-bottom:10px;*/
				margin: 176px 200px;
				box-shadow: 0 0 6px black;
				border-radius: 10px;
				padding: 20px 12px 10px 20px;
				font: 13px Arial, Helvetica, sans-serif;
				border: 1px solid;
			}
	
			.form-heading
			{
				font-weight: bold;
				
				margin-bottom: 20px;
				font-size: 18px;
				
				
				border-bottom: 1px solid #333;
				border-top: 1px solid #333;
				color: #fff;
				border-radius: 10px 10px 0px 0px;
				margin-top:-21px;
				margin-left:-20px;
				text-transform: uppercase;
				background: #d91a29;
				width:101.8%;
				padding: 10px;
			}

			.form-content label
			{
				display: block;
				margin: 0px 0px 15px 0px;
				color: #fff;
			}

			.form-content label > span
			{
				width: 100px;
				font-weight: bold;
				float: left;
				padding-top: 8px;
				padding-right: 5px;
			}
	
			.form-content span.required
			{
				color:red;
			}
		
			.form-content input.input-field
			{
				margin-right:5px;
			}
	
			.form-content input.input-field,
			.form-content .textarea-field, 
			.form-content .select-field
			{
				border: 1px solid #C2C2C2;
				box-shadow: 1px 1px 4px #EBEBEB;
				border-radius: 5px;
				padding: 5px;
			}

			.form-content input[type=submit],
			.form-content input[type=reset]
			{
				margin-top: 5px;
				padding: 10px;
				width: 100px;
				color: #ffffff;
				background: #d91a29;
				text-align: center;
				border-radius: 5px;
			}

			.form-content input[type=submit]:hover,
			.form-content input[type=reset]:hover
			{
				background: #333;
			}
			
		</style>
		
	</head>

	<body>
		<main>
			
			<!-- Form Section -->
			
			<section>
				<div class="form-content">
					<div class="form-heading">Course Information</div>
						<form action="formPersonalInfo.php" name="myform" method="post" autocomplete="off">
							
							<label for="courseName">
								<span>Course Name <span class="required">*</span></span>
									<select name="courseName" id="courseName" class="select-field">
									<option value="Web design & development" selected>Web design & development</option>
									<option value="International Business Management">International Business Management</option>
									<option value="Cyber Security">Cyber Security</option>
									<option value="Cloud Computing">Cloud Computing</option>
									<option value="Business Administration">Business Administration</option>
									<option value="Graphic Design">Graphic Design</option>
								</select>
							</label>
							
							<label for="term">
								<span>Term <span class="required">*</span></span>
									<select name="term" id="term" class="select-field">
									<option value="Term 1" selected>Term 1</option>
									<option value="Term 2">Term 2</option>
									<option value="Term 3">Term 3</option>
									<option value="Term 4">Term 4</option>
								</select>	
							</label>
							
							<label for="grouo">
								<span>Group <span class="required">*</span></span>
									<select name="groupId" id="groupId" class="select-field">
									<option value="Group 1" selected>Group 1</option>
									<option value="Group 2">Group 2</option>
									<option value="Group 3">Group 3</option>
									<option value="Group 4">Group 4</option>
								</select>	
							</label>
							
							<label for="studentId">
							<span>Student Id <span class="required">*</span></span>
								<input type="text" class="input-field" name="studentId" id="studentId" value="" placeholder="Student Id EX - C0711148" required pattern="[A-Za-z]{1}[0-9]{7}+" minlength="8" maxlength="8" title="Please match required Format [C0xxxxxx], Min length & Max length 8 characters." />   <!--(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}-->
							</label>
							
							<label><span>&nbsp;</span>
								<input type="submit" value="Submit" />
								<input type="reset" value="Clear" />
							</label>
							
						</form>
				</div>
			</section>
		</main>
	</body>
</html>