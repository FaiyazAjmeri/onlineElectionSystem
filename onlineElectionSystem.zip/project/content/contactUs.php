<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Index Page</title>
		
		<!-- Style Sheets -->
		<link rel="stylesheet" href="../css/main1.css">
		
		<!-- Java Scripts -->
		<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
		<script src="../js/contactUsValidate.js"></script>
		
		
		<style type="text/css">
			/* Form Section */
			.form-content
			{
				margin-top:10px;
				margin-bottom:10px;
				box-shadow: 0 0 6px #666666;
				border-radius: 10px;
				padding: 20px 12px 10px 20px;
				font: 13px Arial, Helvetica, sans-serif;
				border: 1px solid;
			}
	
			.form-heading
			{
				font-weight: bold;
				
				margin-bottom: 20px;
				font-size: 18px;
				
				
				border-bottom: 1px solid #333;
				border-top: 1px solid #333;
				color: #fff;
				border-radius: 10px 10px 0px 0px;
				margin-top:-21px;
				margin-left:-20px;
				text-transform: uppercase;
				background: #d91a29;
				width:101.1%;
				padding: 10px;
			}

			.form-content label
			{
				display: block;
				margin: 0px 0px 15px 0px;
			}

			.form-content label > span
			{
				width: 100px;
				font-weight: bold;
				float: left;
				padding-top: 8px;
				padding-right: 5px;
			}
	
			.form-content span.required
			{
				color:red;
			}
		
			.form-content input.input-field
			{
				margin-right:5px;
			}
	
			.form-content input.input-field, 
			.form-content .textarea-field, 
			.form-content .select-field
			{
				border: 1px solid #C2C2C2;
				box-shadow: 1px 1px 4px #EBEBEB;
				border-radius: 5px;
				padding: 5px;
			}

			.form-content .textarea-field
			{
				height:60px;
				width: 300px;
			}

			.form-content input[type=submit],
			.form-content input[type=reset]
			{
				margin-top: 5px;
				padding: 10px;
				width: 100px;
				color: #ffffff;
				background: #d91a29;
				text-align: center;
				border-radius: 5px;
			}

			.form-content input[type=submit]:hover,
			.form-content input[type=reset]:hover
			{
				background: #333;
			}

		</style>
	</head>

	<body>

		<main>
			<?php include 'logo.php' ?>
			<?php include 'menu.php' ?>
			<?php include 'contactUsForm.php' ?>
			<?php include 'footer.php' ?>
		</main>
		
	</body>	
</html>

<!--
		<script src="//ajax.googleapis.com/ajax/libs/jquery/1.10.2/jquery.min.js"></script>
		<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
		<script>
			$.validate({
				form : '#contact'
			});
		</script>
-->