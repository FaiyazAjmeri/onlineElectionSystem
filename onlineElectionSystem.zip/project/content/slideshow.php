			<!-- Slideshow -->
			
			<section>
				<div class="slideshow-container">

					<div class="mySlides fade">
							<img src="../image/ele1.jpg" style="width:100%;height:500px">
						<div class="text"></div>
					</div>

					<div class="mySlides fade">
							<img src="../image/ele2.png" style="width:100%;height:500px">
						<div class="text"></div>
					</div>

				</div>
				<br>

				<div style="text-align:center">
					<span class="dot"></span> 
					<span class="dot"></span> 
				</div>
			</section>