<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Index Page</title>
		
		<!-- Style Sheets -->
		<link rel="stylesheet" href="../css/main1.css">
		
		<!-- Java Scripts -->
		<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
		
		
		<style type="text/css">
			/* Form Section */
			.form-content
			{
				margin-top:10px;
				margin-bottom:10px;
				box-shadow: 0 0 6px #666666;
				border-radius: 10px;
				padding: 20px 12px 10px 20px;
				font: 13px Arial, Helvetica, sans-serif;
				border: 1px solid;
			}
	
			.form-content .course
			{
				margin-bottom: 50px;
			}
	
			.form-heading
			{
				font-weight: bold;
				
				margin-bottom: 20px;
				font-size: 18px;
				
				
				border-bottom: 1px solid #333;
				border-top: 1px solid #333;
				color: #fff;
				border-radius: 10px 10px 0px 0px;
				margin-top:-21px;
				margin-left:-20px;
				text-transform: uppercase;
				background: #d91a29;
				width:101.1%;
				padding: 10px;
			}
			
			.form-heading2
			{
				font-weight: bold;
				
				margin-bottom: 20px;
				margin-top: 500px;
				font-size: 18px;
				
				
				border-bottom: 1px solid #333;
				border-top: 1px solid #333;
				color: #fff;
				margin-top:-21px;
				margin-left:-20px;
				text-transform: uppercase;
				background: #d91a29;
				width:101.1%;
				padding: 10px;
			}
			
			.form-heading3
			{
				font-weight: bold;
				
				margin-bottom: 20px;
				font-size: 18px;
				
				
				border-bottom: 1px solid #333;
				border-top: 1px solid #333;
				color: #fff;
				margin-top:27px;
				margin-left:-20px;
				text-transform: uppercase;
				background: #d91a29;
				width:101.1%;
				padding: 10px;
			}

			.form-content label
			{
				display: block;
				margin: 0px 0px 15px 0px;
			}

			.form-content label > span
			{
				width: 100px;
				font-weight: bold;
				float: left;
				padding-top: 8px;
				padding-right: 5px;
			}
	
			.form-content span.required
			{
				color:red;
			}
		
			.form-content input.input-field
			{
				margin-right:5px;
			}
	
			.form-content input.input-field, 
			.form-content .textarea-field, 
			.form-content .select-field
			{
				border: 1px solid #C2C2C2;
				box-shadow: 1px 1px 4px #EBEBEB;
				border-radius: 5px;
				padding: 5px;
			}

			.form-content .textarea-field
			{
				height:60px;
				width: 300px;
			}

			.form-content input[type=submit],
			.form-content input[type=reset]
			{
				margin-top: 5px;
				padding: 10px;
				width: 100px;
				color: #ffffff;
				background: #d91a29;
				text-align: center;
				border-radius: 5px;
			}

			.form-content input[type=submit]:hover,
			.form-content input[type=reset]:hover
			{
				background: #333;
			}

		</style>
	</head>

	<body>

		<main>
			<?php include 'logo.php' ?>
			<?php include 'menu.php' ?>
			
			<?php 
			
			include 'connect.php';
			
			//echo $_GET['emailId'];
			$sql = "SELECT * FROM registrationcandidate where id=".$_POST['id']."";
			//echo $sql;
			
			$result = $conn->query($sql);
			//echo gettype($result);  check type
			
			//print_r($result);
			
			if($result->num_rows > 0) 
			{
				
				while($row = $result->fetch_assoc()) 
				{ 
					$id = $row['id'];
					$courseName = $row['courseName'];
					$term = $row['term'];
					$groupId = $row['groupId'];
					$studentId = $row['studentId'];
					$firstName = $row['firstName'];
					$lastName = $row['lastName'];
					$emailId = $row['emailId'];
					$mobile = $row['mobileNo'];
					$address1 = $row['address1'];
					$address2 = $row['address2'];
					$city = $row['city'];
					
					$strength = $row['strength'];
					$weakness = $row['weakness'];
					$meanByCR = $row['meanByCR'];
					$doYouDo = $row['doYouDo'];
			?>
			
			<section>
				<div class="form-content">
					<div class="form-heading">Course Information</div>
						<form action="candidateIndexEditProfileData.php" name="voterEditProfile" id="voterEditProfile" method="post">
						
							<input type="hidden" name="id" id="id" value="<?php echo $id; ?>" />
							
							<div class="course">
							<label for="courseName">
								<span>Course Name <span class="required">*</span></span>
									<select name="courseName" id="courseName" class="select-field">
										<option value="<?php echo $courseName; ?>"><?php echo $courseName; ?></option>
									</select>
							</label>
							
							<label for="term">
								<span>Term <span class="required">*</span></span>
									<select name="term" id="term" class="select-field">
										<option value="<?php echo $term; ?>"><?php echo $term; ?></option>
									</select>	
							</label>
							
							<label for="grouo">
								<span>Group <span class="required">*</span></span>
									<select name="group" id="group" class="select-field">
										<option value="<?php echo $groupId; ?>"><?php echo $groupId; ?></option>
									</select>	
							</label>
							
							<label for="studentId">
							<span>Student Id <span class="required">*</span></span>
								<input type="text" class="input-field" name="studentId" id="studentId" value="<?php echo $studentId; ?>" />
							</label>
							</div>	
							
							<div class="form-heading2">Personal Information</div>
							
							<label for="firstName">
								<span>Name <span class="required">*</span></span>
								<input type="text" class="input-field" name="firstName" id="firstName" value="<?php echo $firstName; ?>" />
								<input type="text" class="input-field" name="lastName" id="lastName" value="<?php echo $lastName; ?>" />
							</label>
							
							<label for="email"><span>Email <span class="required">*</span></span>
								<input type="email" class="input-field" name="emailId" id="emailId" value="<?php echo $emailId; ?>" />
							</label>
							
							<label for="mobile"><span>Mobile No.<span class="required">*</span></span>
								<input type="text" class="input-field" name="mobile" id="mobile" value="<?php echo $mobile; ?>" />
							</label>
							<label for="addLine1"><span>Address</span>
								<input type="text" class="input-field" name="addLine1" id="addLine1" value="<?php echo $address1; ?>" />
								<input type="text" class="input-field" name="addLine2" id="addLine2" value="<?php echo $address2; ?>" />
							</label>
							<label for="city"><span>City<span class="required">*</span></span>
								<select name="city" id="city" class="select-field">
									<option value="<?php echo $city; ?>"><?php echo $city; ?></option>
								</select>
							</label>
							<label for="country"><span>Country</span>
								<input type="text" class="input-field" name="country" id="country" value="Canada" readonly />
							</label>
							
							<div class="form-heading3">Additional Information</div>
							
							<label for="strength"><span>Strength</span>
								<textarea class="textarea-field" placeholder="Show your Strength..." name="strength" id="strength">
									<?php echo $strength; ?>
								</textarea>
							</label>
							
							<label for="weakness"><span>Weakness</span>
								<textarea class="textarea-field" placeholder="Show your Weakness..." name="weakness" id="weakness">
									<?php echo $weakness; ?>
								</textarea>
							</label>
							
							<label for="you do"><span>What do you mean by CR?</span>
								<textarea class="textarea-field" placeholder="What do you mean by Class Representative?" name="meanByCR" id="meanByCR">
									<?php echo $meanByCR; ?>
								</textarea>
							</label>
							
							<label for="you do"><span>What do you do?</span>
								<textarea class="textarea-field" placeholder="What do you do as a Class Representative?" name="doYouDo" id="doYouDo">
									<?php echo $doYouDo; ?>
								</textarea>
							</label>
							
							<!--
							<label for="comments"><span>Comments</span>
								<textarea class="textarea-field">
	
								</textarea>
							</label>
							-->
							<label><span>&nbsp;</span>
								<input type="submit" value="Update" />
								<input type="reset" value="Clear" />
							</label>
						</form>
				</div>
			</section>
			<?php
				}
			}
			else
			{
				echo "0 Results";
			}
			$conn->close();
			?>
			
			<?php include 'footer.php' ?>
		</main>
		
	</body>	
</html>
