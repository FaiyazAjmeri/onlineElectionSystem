			<!-- Event Section -->
			<section> 
				<div id="eventPanel">
					<div id="event">
					<h3 class="titlebar">Event 1</h3>
						<div class="container">
							<img src="../image/profileicon.png" class="eventProfile">
							<div class="overlay">
								<div class="content">
									Name : Faiyaz <br>
									Course : WDEM <br>
									Term : 3 <br>
									Group : G2
								</div>
							</div>
						</div>
					</div>
					
					<div id="event">
					<h3 class="titlebar">Event 2</h3>
						<div class="container">
							<img src="../image/profileicon.png" class="eventProfile">
							<div class="overlay">
								<div class="content">
									Name : Student 2 <br>
									Course : WDEM <br>
									Term : 3 <br>
									Group : G2
								</div>
							</div>
						</div>
					</div>
					
					<div id="event">
					<h3 class="titlebar">Event 3</h3>
						<div class="container">
							<img src="../image/profileicon.png" class="eventProfile">
							<div class="overlay">
								<div class="content">
									Name : Student 3 <br>
									Course : WDEM <br>
									Term : 3 <br>
									Group : G2
								</div>
							</div>
						</div>
					</div>
				</div>
			</section>