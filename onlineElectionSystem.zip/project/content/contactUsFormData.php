<?php include 'connect.php' ?>
<?php
$firstName = $_POST['firstName'];
$lastName = $_POST['lastName'];
$emailId = $_POST['emailId'];
$comment = $_POST['comment'];

$sql = "INSERT INTO contact (firstName, lastName, emailId, comment)
VALUES ('$firstName', '$lastName', '$emailId', '$comment')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

header('Location: index.php');    

?>