<?php
	include('session.php');	
	include 'connect.php';
	
	//$username = $_GET['emailId'];
		/*$emailId = $_SESSION['login_user'];
	
		if(isset($_SESSION['login_user']))
		{
			header("location: voterIndex.php?emailId=$emailId");
		}*/
?>

<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Voter Index Page</title>
		
		<!-- Style Sheets -->
		<link rel="stylesheet" href="../css/main1.css">
		
		<style type="text/css">
		
			/* Form Section */
			.form-content
			{
				margin-top:10px;
				margin-bottom:10px;
				box-shadow: 0 0 6px #666666;
				border-radius: 10px;
				padding: 20px 12px 10px 20px;
				font: 13px Arial, Helvetica, sans-serif;
				border: 1px solid;
			}
	
			.form-content .course
			{
				margin-bottom: 50px;
			}
	
			.form-heading
			{
				font-weight: bold;
				
				margin-bottom: 20px;
				font-size: 18px;
				
				
				border-bottom: 1px solid #333;
				border-top: 1px solid #333;
				color: #fff;
				border-radius: 10px 10px 0px 0px;
				margin-top:-21px;
				margin-left:-20px;
				text-transform: uppercase;
				background: #d91a29;
				width:101.1%;
				padding: 10px;
			}
			
			.form-heading2
			{
				font-weight: bold;
				
				margin-bottom: 20px;
				margin-top: 500px;
				font-size: 18px;
				
				
				border-bottom: 1px solid #333;
				border-top: 1px solid #333;
				color: #fff;
				margin-top:-21px;
				margin-left:-20px;
				text-transform: uppercase;
				background: #d91a29;
				width:101.1%;
				padding: 10px;
			}

			.form-content label
			{
				display: block;
				margin: 0px 0px 15px 0px;
			}

			.form-content label > span
			{
				width: 100px;
				font-weight: bold;
				float: left;
				padding-top: 8px;
				padding-right: 5px;
			}
	
			.form-content span.required
			{
				color:red;
			}
		
			.form-content input.input-field
			{
				margin-right:5px;
			}
	
			.form-content input.input-field, 
			.form-content .textarea-field, 
			.form-content .select-field
			{
				border: 1px solid #C2C2C2;
				box-shadow: 1px 1px 4px #EBEBEB;
				border-radius: 5px;
				padding: 5px;
			}

			.form-content .textarea-field
			{
				height:60px;
				width: 300px;
			}

			.form-content input[type=submit],
			.form-content input[type=button],
			.form-content input[type=reset]
			{
				margin-top: 5px;
				padding: 10px;
				width: 100px;
				color: #ffffff;
				background: #d91a29;
				text-align: center;
				border-radius: 5px;
			}

			.form-content input[type=submit]:hover,
			.form-content input[type=button]:hover,
			.form-content input[type=reset]:hover
			{
				background: #333;
			}
			
			/* Candidate Information */
		
			#event .container .overlay
			{
				position: absolute;
				bottom: 0;
				left: 0;
				right: 0;
				background-color: #333;
				overflow: hidden;
				width: 100%;
				height: 101%;
				-webkit-transform:scale(0);
				transition: .3s ease;
				border-radius: 0px;
				margin-bottom: -2.5px;
			}
		
			#eventPanel #event #candbtn input[type=button]
			{
				margin-top: -80px;
				margin-left:0px;
				width: 100%;
				border-radius: 0px 0px 10px 10px;
				border-width:0px;
				border-top: 1px solid black;
				color: #fff;
				text-transform: uppercase;
				background: #d91a29;
				padding: 10px;
				font-family: "Lucida Grande", "Lucida Sans Unicode", "Lucida Sans", "DejaVu Sans", Verdana, "sans-serif";
				font-size: 100%;
				text-align: center;
				font-weight:bold;
			}

			#eventPanel #event #candbtn input[type=button]:hover
			{
				background: #333;
			}
		</style>
		
		<!-- Java Scripts -->
		<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
	</head>

	<body>

		<main>
			<?php //echo $login_session; ?>
		
			<?php include 'logo.php' ?>
			<?php include 'menu.php' ?>
			
			<!-- Form Section -->
			<?php 
			
			if(isset($_SESSION['login_user']))
			{
				$sql = "SELECT * FROM registrationvoter where emailId='".$_SESSION['login_user']."'";
			}
			else
			{
				//echo $_GET['emailId'];
				$sql = "SELECT * FROM registrationvoter where emailId='".$_GET['emailId']."'";
				//echo $sql;
			}
			
			
			
			$result = $conn->query($sql);
			//echo gettype($result);  check type
			
			//print_r($result);
			
			if($result->num_rows > 0) 
			{
				
				while($row = $result->fetch_assoc()) 
				{ 					
					$id = $row['id'];
					$courseName = $row['courseName'];
					$term = $row['term'];
					$groupId = $row['groupId'];
					$studentId = $row['studentId'];
					$firstName = $row['firstName'];
					$lastName = $row['lastName'];
					$emailId = $row['emailId'];
					$mobile = $row['mobileNo'];
					$address1 = $row['address1'];
					$address2 = $row['address2'];
					$city = $row['city'];
			?>
			
			<section>
				<div class="form-content">
					<div class="form-heading">Personal information</div>
						<form action="voterIndexEditProfile.php" name="personalInfo" id="personalInfo" method="post">
						
							<input type="hidden" name="id" id="id" value="<?php echo $id; ?>">
							
							<label for="studentId">
							<span>Student Id</span>
								<input type="text" class="input-field" name="studentId" id="studentId" value="<?php echo $studentId; ?>" readonly />
							</label>
						
							<label for="firstName">
								<span>Name</span>
								<input type="text" class="input-field" name="firstName" value="<?php echo $firstName; ?>" id="firstName" readonly />
								<input type="text" class="input-field" name="lastName" value="<?php echo $lastName; ?>" id="lastName" readonly />
							</label>
							
							<label for="email"><span>Email</span>
								<input type="text" class="input-field" name="emailId" id="emailId" value="<?php echo $emailId; ?>" readonly />
							</label>
							
							<label><span>&nbsp;</span>
								<input type="submit" value="Edit Profile" />
								<a href="logout.php"><input type="button" value="Logout" /></a>
							</label>
						</form>
				</div>
			</section>
			
			
			
			<!-- Event Section -->
			
			<section> 
				
				<div id="eventPanel">
					<?php
						$vcourseName = $courseName;
						$vterm = $term;
						$vgroupId = $groupId;
					
						$sql = "SELECT * FROM registrationcandidate WHERE courseName = '".$vcourseName."' AND term = '".$vterm."' AND groupId = '".$vgroupId."'";
						$result = $conn->query($sql);
				
						if ($result->num_rows > 0) 
						{
							$i = 1;
							while($row = $result->fetch_assoc()) 
							{
								$emailId = $row['emailId'];
					?>
					<!-- candidate 1-->
					<div id="event">
						<div id="candinfo">
							<h3 class="titlebar">Candidate <?php echo $i; ?></h3>
								<div class="container">
									<img src="../image/profileicon.png" class="eventProfile">
									<div class="overlay">
										<div class="content">
											Name : <?php echo $row["firstName"]." ".$row["lastName"]; ?> <br>
											Course : <?php echo $row["courseName"]; ?> <br>
											Term : <?php echo $row["term"]; ?> <br>
											Group : <?php echo $row["groupId"]; ?>
										</div>
									</div>
								</div>
						</div>
						
						<div id="candbtn">
							<label><span>&nbsp;</span>
								<a href="voterIndexCandidateMoreInfo.php?emailId=<?php echo $emailId; ?>&voterId=<?php echo $id; ?>">
								<input type="button" value="View more information" />
								</a>
							</label>
						</div>
					</div>
				
					<?php	
							$i = $i+1;
						}
					} 
					else 
					{
						echo "0 results";
					}
					
				}
			}
			else
			{
				echo "0 Results";
			}
			//$conn->close();
					$conn->close();
					
					?>
				
					
				</div>
			</section>
			
			<?php include 'footer.php' ?>
		</main>

	</body>	
</html>