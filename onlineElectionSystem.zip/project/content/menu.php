		<nav>
			<div id="header">
				<ul class="menu fontstyle">
					<li><a href="index.php">Home</a></li>
					<li><a href="result.php">Results</a>
					<!--	<ul class="submenu">
							<li><a href="#">Sub - menu 1</a></li>
							<li><a href="#">Sub - menu 2</a></li>
							<li><a href="#">Sub - menu 3</a></li>
							<li><a href="#">Sub - menu 4</a></li>
							<li><a href="#">Sub - menu 5</a></li>
						</ul>-->
					</li>
					<li>About Us</li>
					<li><a href="contactUs.php">Contact Us</a></li>
					<li>
						<?php 
							if(isset($_SESSION['login_user']))
							{
						?>
								<a href="voterIndex.php?emailId=<?php echo $_SESSION['login_user'];?>"> WELCOME </a>
						<?php
							}
							else
							{
						?>
								<a href="formLogin.php">Login</a>
						<?php		
							}
						?>
						
						
					</li>
				</ul>
			</div>
		<nav>
		
		
		
		