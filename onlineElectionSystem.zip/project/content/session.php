<?php
	// Establishing Connection with Server by passing server_name, user_id and password as a parameter
	$connection = mysql_connect("localhost", "root", "");

	// Selecting Database
	$db = mysql_select_db("eballot", $connection);
	
	// Starting Session
	session_start();
	
	// Storing Session
	$user_check=$_SESSION['login_user'];
	//$user_firstName = $_SESSION['login_user_firstName'];

	// SQL Query To Fetch Complete Information Of User
	$ses_sql=mysql_query("select emailId from registrationVoter where emailId='$user_check'", $connection);
	$row = mysql_fetch_assoc($ses_sql);
	
	$login_session =$row['emailId'];
	if(!isset($login_session))
	{
		mysql_close($connection); // Closing Connection
		header('Location: formLogin.php'); // Redirecting To Home Page
	}
?>