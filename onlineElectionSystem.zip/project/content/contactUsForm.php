			<!-- Form Section -->
			
			<section>
				<div class="form-content">
					<div class="form-heading">Contact Information</div>
						<form action="contactUsFormData.php" name="contactForm" id="contactForm" method="post">
							
							<label for="name">
								<span>Name <span class="required">*</span></span>
								<input type="text" class="input-field" name="firstName" id="firstName" value="" placeholder="First Name" />
								<input type="text" class="input-field" name="lastName" id="lastName" value="" placeholder="Last Name" />
									<span id="firstName_error"></span>
									<!-- data-validation="required" -->
							</label>
							
							<label for="email">
								<span>Email <span class="required">*</span></span>
								<input type="text" class="input-field" name="emailId" id="emailId" value="" placeholder="Email Address" />
									<span id="emailId_error"></span>
							</label>
							
							<label for="comments"><span>Comments <span class="required">*</span></span>
								<textarea class="textarea-field" name="comment" id="comment">
	
								</textarea>
								<span id="comment_error"></span>
							</label>
							<label><span>&nbsp;</span>
								<input type="submit" value="Submit" id="validate" name="validate" />
								<input type="reset" value="Clear" />
							</label>
						</form>
				</div>
			</section>