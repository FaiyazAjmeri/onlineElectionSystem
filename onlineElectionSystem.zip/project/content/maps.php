			<!-- Map Section -->
			
			<section>
				<div id="w" class="float-left w">
				<div id="mapSection" class="float-left w-67">
					<div class="heading">Location</div>
					<div id="map"></div>
				</div>
				<div id="contactSection" class="float-left w-23">
					<div class="heading">Contact Details</div>
					<div class="contactInfo">
						<div class="contactInfoSection">
							<div class="contactInfoHeading">Sarnia</div>
							Lambton College,<br>
							1457 London Road,<br>
							Sarnia,<br>
							ON, N7S6K4.
						</div>
						<div class="contactInfoSection">
							<div class="contactInfoHeading">Mississuage</div>
							Lambton College,<br>
							121 Brunel Road,<br>
							Mississuage,<br>
							ON<br>
							phone : +1 (647) 544 8792
						</div>
					</div>
				</div>
				</div>
			</section>