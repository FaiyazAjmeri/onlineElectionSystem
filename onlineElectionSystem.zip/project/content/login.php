<?php include 'connect.php' ?>
<?php 

	session_start();
	$error='';
	
	if(isset($_POST['submit']))
	{
		if(empty($_POST['username']) || empty($_POST['password'] || empty($_POST['type'])))
		{	
			//header("location: formLogin.php");
			$error = "User name or Password is invalid";
		}
		else
		{
			$username = $_POST['username'];
			$password = $_POST['password'];
			$type = $_POST['type'];
			
			// To protect MySQL injection for Security purpose
			$username = stripslashes($username);
			$password = stripslashes($password);
			$username = mysql_real_escape_string($username);
			$password = mysql_real_escape_string($password);
			
			if($type == 'voter')
			{
				$sql = "SELECT * FROM registrationVoter WHERE emailId = '$username' AND password = '$password'";
				$result = $conn->query($sql);
			
				if ($result == 1) 
				{
						//For User Name to show in Menu
						/*if($result->num_rows > 0) 
						{
							while($row = $result->fetch_assoc()) 
							{
								$_SESSION['user_firstName'] = $row['firstName'];
							}
						}*/
						
						
					$_SESSION['login_user_firstName']=$row['firstName'];	
					$_SESSION['login_user']=$username; // Initializing Session
					header("location: voterIndex.php?emailId=$username"); // Redirecting To Other Page
				} 
				else 
				{
					$error = "Username or Password is invalid";
				}
			}
			else
			{
				$sql = "SELECT * FROM registrationcandidate WHERE emailId = '$username' AND password = '$password'";
				$result = $conn->query($sql);
			
				if ($result == 1) 
				{
					$_SESSION['login_user']=$username; // Initializing Session
					header("location: candidateIndex.php?emailId=$username"); // Redirecting To Other Page
				} 
				else 
				{
					$error = "Username or Password is invalid";
				}
			}
			
			
			
		}
	}
?>