<?php
	include('session.php');	
	include 'connect.php';
	
	//$username = $_GET['emailId'];
?>

<!doctype html>
<html>
	<head>
		<meta charset="utf-8">
		<title>Voter Index Page</title>
		
		<!-- Style Sheets -->
		<link rel="stylesheet" href="../css/main1.css">
		
		<style type="text/css">
			.table
			{
				font-family: "Lucida Grande", "Lucida Sans Unicode", "Lucida Sans", "DejaVu Sans", "sans-serif";
				color: #d91a29;
				//margin-left: 9%;
				margin-top : 20px;
				margin-bottom: 20px;
				width: 100%;
				border: 1px dotted #d91a29;
			}
			
			.table .heading
			{
				background: #d91a29;
				color: #fff;
				font-size: 200%;
				padding: 10px;
				height: 50px;
			}
			
			.table tr:hover
			{
				background: #333;
				color: #fff;
			}
			
			.table td
			{
				padding: 10px;
			}
			
			#votebtn input[type=submit]
			{
				margin-left: 9%;
				margin-bottom: 20px;
				width: 80%;
				border: 1px solid #d91a29;
				color: #fff;
				text-transform: uppercase;
				background: #d91a29;
				padding: 10px;
				font-family: "Lucida Grande", "Lucida Sans Unicode", "Lucida Sans", "DejaVu Sans", Verdana, "sans-serif";
				font-size: 120%;
				text-align: center;
			}

			#votebtn input[type=submit]:hover
			{
				background: #333;
			}
		</style>
		
		<!-- Java Scripts -->
		<script src="http://code.jquery.com/jquery-2.1.4.min.js"></script>
	</head>

	<body>

		<main>
			<?php //echo $login_session; ?>

			<?php include 'logo.php' ?>
			<?php include 'menu.php' ?>
			
			<!-- Event Section -->
			
			<section> 
				
				<?php 
					$voterId = $_GET['voterId'];
					$emailId = $_GET['emailId'];
					
					$sql = "SELECT * FROM registrationvoter where id=".$_GET['voterId']."";
					$result = $conn->query($sql);
					
			if($result->num_rows > 0) 
			{
				
				while($row = $result->fetch_assoc()) 
				{
					$voterId = $row['id'];
					$vcourseName = $row['courseName'];
					$vterm = $row['term'];
					$vgroupId = $row['groupId'];
					$vstudentId = $row['studentId'];
					$vfirstName = $row['firstName'];
					$vlastName = $row['lastName'];
					$vemailId = $row['emailId'];
					$vmobile = $row['mobileNo'];
					$vaddress1 = $row['address1'];
					$vaddress2 = $row['address2'];
					$vcity = $row['city'];
					//echo $voterId;
					
					$sql = "SELECT * FROM registrationcandidate WHERE emailId='".$emailId."'";
					$result = $conn->query($sql);

					if ($result->num_rows > 0) 
					{
						while($row = $result->fetch_assoc()) 
						{
						$cid = $row["id"];
						$cfirstName = $row["firstName"];
						$clastName = $row["lastName"];
						
							//echo $id;
						
						echo "<table class='table'>";
						
						echo "<tr class='heading'>
									<th colspan='2'><h1>". $row["firstName"]." ".$row['lastName'] ."</h1></th>
							</tr>";
						
						echo "<tr>
								<td width='30%'>StudentId : </td>
								<td>".$row["studentId"]."</td>
							</tr>";
							
						echo "<tr>
								<td>Course Name : </td>
								<td>".$row["courseName"]."</td>
							</tr>";
						
						echo "<tr>
								<td>Term : </td>
								<td>".$row["term"]."</td>
							</tr>";
							
						echo "<tr>
								<td>Group Id : </td>
								<td>".$row["groupId"]."</td>
							</tr>";
							
						echo "<tr>
								<td>Strength : </td>
								<td>".$row["strength"]."</td>
							</tr>";
							
						echo "<tr>
								<td>Weakness : </td>
								<td>".$row["weakness"]."</td>
							</tr>";
							
						echo "<tr>
								<td>What do you mean by CR? : </td>
								<td>".$row["meanByCR"]."</td>
							</tr>";
							
						echo "<tr>
								<td>What do I do? : </td>
								<td>".$row["doYouDo"]."</td>
							</tr>";
							
						echo "</table>";
						
						echo "<div id='votebtn'>
								<label>
									<form action='voterIndexVoting.php' name='vote' method='POST'>
										
										<input type='hidden' name='cid' id='cid' value=".$cid." />
										<input type='hidden' name='cfirstName' id='cfirstName' value='".$cfirstName."' />
										<input type='hidden' name='clastName' id='clastName' value='".$clastName."' />
										
										<input type='hidden' name='voterId' id='voterId' value=".$voterId." />
										<input type='hidden' name='vcourseName' id='vcourseName' value='".$vcourseName."' />
										<input type='hidden' name='vterm' id='vterm' value='".$vterm."' />
										<input type='hidden' name='vgroupId' id='vgroupId' value='".$vgroupId."' />
										<input type='hidden' name='vstudentId' id='vstudentId' value='".$vstudentId."' />
										<input type='hidden' name='vfirstName' id='vfirstName' value='".$vfirstName."' />
										<input type='hidden' name='vlastName' id='vlastName' value='".$vlastName."' />
										<input type='hidden' name='vemailId' id='vemailId' value='".$vemailId."' />
										<input type='hidden' name='vmobile' id='vmobile' value=".$vmobile." />
										<input type='hidden' name='vaddress1' id='vaddress1' value='".$vaddress1."' />
										<input type='hidden' name='vaddress2' id='vaddress2' value='".$vaddress2."' />
										<input type='hidden' name='vcity' id='vcity' value='".$vcity."' />  
									
										<input type='submit' value='Vote for ". $row['firstName']." ".$row['lastName'] ." ' />
									</form>
								</label>
							</div>";
						}
					
					
					} else {
						echo "0 results";
					}
					
				}
					
			} else {
				echo "0 results";
			}
			$conn->close();
			?>
				
			</section>
			
			<?php include 'footer.php' ?>
		</main>

	</body>	
</html>